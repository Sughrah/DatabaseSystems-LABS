-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2026 at 10:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cargo_rentals`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `RegisterRental` (IN `p_customer_id` INT, IN `p_vehicle_id` INT, IN `p_rental_date` DATE, IN `p_rental_days` INT)   BEGIN
    DECLARE v_daily_rate DECIMAL(10,2);
    DECLARE v_charge DECIMAL(10,2);

    SELECT DailyRate
    INTO v_daily_rate
    FROM Vehicles
    WHERE VehicleID = p_vehicle_id
    AND Status = 'Available';

    IF v_daily_rate IS NULL THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Vehicle is not available.';
    END IF;

    SET v_charge = v_daily_rate * p_rental_days;

    INSERT INTO Rentals
    (CustomerID, VehicleID, RentalDate, RentalDays,
     RentalCharge, RentalStatus)
    VALUES
    (p_customer_id, p_vehicle_id, p_rental_date,
     p_rental_days, v_charge, 'Active');

    UPDATE Vehicles
    SET Status = 'Rented'
    WHERE VehicleID = p_vehicle_id;

    SELECT v_charge AS CalculatedCharge;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `CustomerID` int(11) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`CustomerID`, `FullName`, `Phone`, `Email`, `Address`, `CreatedAt`) VALUES
(1, 'Ali Khan', '0300-1234567', 'ali@gmail.com', 'Muzaffarabad', '2026-09-20 13:17:10'),
(2, 'Sara Ahmed', '0311-2223344', 'sara@gmail.com', 'Islamabad', '2026-09-20 13:17:10'),
(3, 'Hamza Malik', '0322-3334455', 'hamza@gmail.com', 'Rawalpindi', '2026-09-20 13:17:10'),
(4, 'Ayesha Noor', '0333-4445566', 'ayesha@gmail.com', 'Abbottabad', '2026-09-20 13:17:10'),
(5, 'Usman Tariq', '0344-5556677', 'usman@gmail.com', 'Lahore', '2026-09-20 13:17:10');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `PaymentID` int(11) NOT NULL,
  `RentalID` int(11) NOT NULL,
  `PaymentAmount` decimal(10,2) NOT NULL CHECK (`PaymentAmount` > 0),
  `PaymentDate` datetime DEFAULT current_timestamp(),
  `PaymentMethod` enum('Cash','Card','Online') DEFAULT 'Cash'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`PaymentID`, `RentalID`, `PaymentAmount`, `PaymentDate`, `PaymentMethod`) VALUES
(1, 1, 15000.00, '2026-09-20 13:29:31', 'Cash'),
(2, 2, 16500.00, '2026-09-20 13:29:31', 'Card'),
(3, 3, 13000.00, '2026-09-20 13:29:31', 'Online'),
(4, 4, 8000.00, '2026-09-20 13:29:31', 'Cash');

-- --------------------------------------------------------

--
-- Table structure for table `rentals`
--

CREATE TABLE `rentals` (
  `RentalID` int(11) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  `VehicleID` int(11) NOT NULL,
  `RentalDate` date NOT NULL,
  `ReturnDate` date DEFAULT NULL,
  `RentalDays` int(11) NOT NULL CHECK (`RentalDays` > 0),
  `RentalCharge` decimal(10,2) NOT NULL CHECK (`RentalCharge` >= 0),
  `RentalStatus` enum('Active','Returned','Cancelled') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rentals`
--

INSERT INTO `rentals` (`RentalID`, `CustomerID`, `VehicleID`, `RentalDate`, `ReturnDate`, `RentalDays`, `RentalCharge`, `RentalStatus`) VALUES
(1, 1, 1, '2026-09-01', '2026-09-04', 3, 15000.00, 'Active'),
(2, 2, 4, '2026-09-10', '2026-09-13', 3, 16500.00, 'Active'),
(3, 3, 2, '2026-08-20', '2026-08-22', 2, 13000.00, 'Returned'),
(4, 1, 3, '2026-08-01', '2026-08-03', 2, 8000.00, 'Returned'),
(5, 4, 6, '2026-09-19', NULL, 4, 20800.00, 'Active');

--
-- Triggers `rentals`
--
DELIMITER $$
CREATE TRIGGER `before_rental_insert` BEFORE INSERT ON `rentals` FOR EACH ROW BEGIN
    IF EXISTS (
        SELECT 1
        FROM Rentals
        WHERE VehicleID = NEW.VehicleID
        AND RentalStatus = 'Active'
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Vehicle is already rented.';
    END IF;

    IF EXISTS (
        SELECT 1
        FROM Vehicles
        WHERE VehicleID = NEW.VehicleID
        AND Status <> 'Available'
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Vehicle is not available for rental.';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `rental_report_view`
-- (See below for the actual view)
--
CREATE TABLE `rental_report_view` (
`RentalID` int(11)
,`FullName` varchar(100)
,`Phone` varchar(20)
,`VehicleNumber` varchar(20)
,`VehicleModel` varchar(100)
,`DailyRate` decimal(10,2)
,`RentalDate` date
,`ReturnDate` date
,`RentalDays` int(11)
,`RentalCharge` decimal(10,2)
,`RentalStatus` enum('Active','Returned','Cancelled')
,`PaymentAmount` decimal(10,2)
,`PaymentMethod` enum('Cash','Card','Online')
,`PaymentDate` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `VehicleID` int(11) NOT NULL,
  `VehicleNumber` varchar(20) NOT NULL,
  `VehicleModel` varchar(100) NOT NULL,
  `DailyRate` decimal(10,2) NOT NULL CHECK (`DailyRate` > 0),
  `Status` enum('Available','Rented','Maintenance') DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`VehicleID`, `VehicleNumber`, `VehicleModel`, `DailyRate`, `Status`) VALUES
(1, 'ABC-123', 'Toyota Corolla', 5000.00, 'Rented'),
(2, 'LEA-456', 'Honda Civic', 6500.00, 'Available'),
(3, 'ISB-789', 'Suzuki Swift', 4000.00, 'Available'),
(4, 'MZD-321', 'Toyota Yaris', 5500.00, 'Rented'),
(5, 'RWP-654', 'Kia Sportage', 8000.00, 'Maintenance'),
(6, 'ABB-987', 'Honda City', 5200.00, 'Rented');

-- --------------------------------------------------------

--
-- Structure for view `rental_report_view`
--
DROP TABLE IF EXISTS `rental_report_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `rental_report_view`  AS SELECT `r`.`RentalID` AS `RentalID`, `c`.`FullName` AS `FullName`, `c`.`Phone` AS `Phone`, `v`.`VehicleNumber` AS `VehicleNumber`, `v`.`VehicleModel` AS `VehicleModel`, `v`.`DailyRate` AS `DailyRate`, `r`.`RentalDate` AS `RentalDate`, `r`.`ReturnDate` AS `ReturnDate`, `r`.`RentalDays` AS `RentalDays`, `r`.`RentalCharge` AS `RentalCharge`, `r`.`RentalStatus` AS `RentalStatus`, `p`.`PaymentAmount` AS `PaymentAmount`, `p`.`PaymentMethod` AS `PaymentMethod`, `p`.`PaymentDate` AS `PaymentDate` FROM (((`rentals` `r` join `customers` `c` on(`r`.`CustomerID` = `c`.`CustomerID`)) join `vehicles` `v` on(`r`.`VehicleID` = `v`.`VehicleID`)) left join `payments` `p` on(`r`.`RentalID` = `p`.`RentalID`)) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`CustomerID`),
  ADD UNIQUE KEY `Phone` (`Phone`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `fk_payment_rental` (`RentalID`);

--
-- Indexes for table `rentals`
--
ALTER TABLE `rentals`
  ADD PRIMARY KEY (`RentalID`),
  ADD KEY `fk_rental_customer` (`CustomerID`),
  ADD KEY `fk_rental_vehicle` (`VehicleID`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`VehicleID`),
  ADD UNIQUE KEY `VehicleNumber` (`VehicleNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `PaymentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rentals`
--
ALTER TABLE `rentals`
  MODIFY `RentalID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `VehicleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `fk_payment_rental` FOREIGN KEY (`RentalID`) REFERENCES `rentals` (`RentalID`);

--
-- Constraints for table `rentals`
--
ALTER TABLE `rentals`
  ADD CONSTRAINT `fk_rental_customer` FOREIGN KEY (`CustomerID`) REFERENCES `customers` (`CustomerID`),
  ADD CONSTRAINT `fk_rental_vehicle` FOREIGN KEY (`VehicleID`) REFERENCES `vehicles` (`VehicleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
